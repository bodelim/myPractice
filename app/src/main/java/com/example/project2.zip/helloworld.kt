package com.example.project2

fun main() {
    var hello: String? = "hello world"

    print(hello)
}

fun hello2(): String {
    return ""
}